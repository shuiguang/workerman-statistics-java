<?php
\Statistics\Lib\Cache::$ServerIpList=array (
  '192.168.52.1' => '192.168.52.1',
);