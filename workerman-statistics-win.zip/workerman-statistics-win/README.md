服务端所需环境
========

需要PHP版本不低于5.3，只需要安装PHP的Cli即可，无需安装PHP-FPM、nginx、apache


示例
========
[Live Demo](http://www.workerman.net:55757/)

安装
=========

以windows为例

安装PHP，双击start_for_win.bat启动监控服务端

如果启动start_for_win.bat报错说明未添加pthreads扩展，其中PHP各个版本扩展dll的均已提供下载。

该压缩包有2个dll文件：php_pthreads.dll是php的ext下扩展文件；pthreadVC2是windows系统的动态库文件：32位复制到C:\Windows\System32下，64位复制到C:\Windows\SysWOW64下。
然后在php.ini中添加extension=php_pthreads.dll，然后重启PHP即可。


Linux系统上运行
======
版本升级：[https://github.com/walkor/workerman-statistics](https://github.com/walkor/workerman-statistics)

环境要求参见：[http://doc3.workerman.net/install/requirement.html](http://doc3.workerman.net/install/requirement.html)

启动  
`php start.php start -d`

重启启动  
`php start.php restart`

平滑重启/重新加载配置  
`php start.php reload`

查看服务状态  
`php start.php status`

停止  
`php start.php stop`


权限验证
=======

  *  管理员用户名密码默认都为空，即不需要登录就可以查看监控数据
  *  如果需要登录验证，在applications/Statistics/Config/Config.php里面设置管理员密码

